var project = angular.module ('project');

project.controller('editCtrl', function($scope, $location, $routeParams, $http) {

 (function setItem() {

     var id = $routeParams.id;
     var items = localStorage.getItem('items');
   if(id) {
     angular.forEach(items, function(obj) {
       if(obj.id === id) {
        alert(obj.id)
         //$location.path('/vehicle');
       }
     });
   }
 })();
});
